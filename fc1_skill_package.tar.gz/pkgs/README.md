# FC1 Skill 发布包

> FlashComm V1 序列并行优化特性的原子能力 Skill——首个打样模板。

## 目录结构

```
pkgs/
├── README.md                    # 本文件
├── flashcomm_v1_skill/          # FC1 Skill 本体
│   ├── SKILL.md                 #   核心文档（11 节）
│   ├── assets/
│   │   ├── disable_fc1.diff      #   失效方案（eager 4行 + graph 5行）
│   │   ├── prefix_quickref.md    #   前缀速查表
│   │   ├── adaptation_catalog.md #   模型适配目录
│   │   ├── redevelop_comparison.md#   博弈论失效/重做对比
│   │   └── fc1_dataflow.txt      #   数据流示意
│   ├── scripts/
│   │   └── fc1_check.py          #   运行时自检
│   └── templates/                #   新模型适配模板
└── remote_scripts/              # 远程验证辅助脚本
    ├── README.md
    ├── remote_exec.sh
    └── remote_display.sh
```

## 使用方法

1. 阅读 `flashcomm_v1_skill/SKILL.md` 了解 FC1 原理和判断链路
2. 用 `assets/` 下的速查表快速判断目标模型是否支持
3. 按 `templates/` 为新模型添加适配
4. 部署后用 `scripts/fc1_check.py` 做运行时自检
5. 参考 `remote_scripts/README.md` 搭建远程验证环境

## 相关文档

配套方法论文章见 `final.md`（讲解如何从 0 到 1 构建一个特性 Skill）。
