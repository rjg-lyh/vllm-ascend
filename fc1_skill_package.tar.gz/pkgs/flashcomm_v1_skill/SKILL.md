---
name: flashcomm-v1
description: >
  FlashComm V1 (FC1) 序列并行适配技能。当用户需要：(1) 判断某模型能否开启 FC1；
  (2) 为新模型/自定义模型添加 FC1 支持； (3) 排查 FC1 不生效或崩溃； (4) 对比 FC1/FC2/SP Pass/DSA-CP 选型；
  (5) 分析 vllm-ascend 序列并行相关代码； (6) 让 FC1 失效（disable）做对比测试时使用本技能。
  触发词：FC1、FlashComm、序列并行、sequence parallel、enable_sp、ReduceScatter+AllGather、
  mmrs_fusion、DSA-CP、shared_expert_dp、ShardedCP、enable_sp_by_pass。
---

# FlashComm V1 (FC1) 适配技能

> 本文档所有断言均基于 vllm-ascend 源码核实，标注 `文件:行号`。行号随仓库演进会漂移，**定位时以函数名/符号名为准，行号仅作参考**。

## 0. TL;DR — 什么时候用这个技能

| 用户场景 | 直接跳到 |
|---------|---------|
| "FC1 是什么/本质是什么" | §1 |
| "FC1、DSA-CP、SP Pass、shared_expert_dp 到底什么关系" | §1.5（四类分离，**最关键**） |
| "X 模型能不能开 FC1？" | §3 决策树 |
| "给新模型加 FC1 支持" | §4 适配 playbook |
| "怎么验证 FC1 真在跑" | §5 运行时验证 |
| "FC1 没生效/崩了" | §6 排查矩阵 |
| "FC1 vs FC2 vs SP Pass vs DSA-CP 怎么选" | §7 选型对比 |
| "让 FC1 失效做对比测试" | §8 失效方案（**区分 eager/graph**） |

---

## 1. 核心机制（物理层 why）

### 1.1 本质：消除模块边界 layernorm 的 TP 冗余

一句话：**FC1 把 RowParallelLinear 后的 AllReduce 拆成 ReduceScatter + 下一个列切 Linear 前的 AllGather，让中间的 RMSNorm/Quant 只在 `bs/TP` 个 token 上算，且 AllGather 传 INT8。**

标准 TP 下，attention/mlp 模块的行切 linear（o_proj / down_proj 等）后做 AllReduce，**每张卡都拿到完整的 `[bs, H]`**。后续的 RMSNorm/Quant 在每张卡上对同样的 `bs` 个 token 重复计算 — 这是 TP 场景下的冗余。

FC1 把这个 AllReduce 拆成两步：

```
标准 TP:  [行切 Linear] → AllReduce → [RMSNorm + Quant](全 bs，每卡重复) → [列切 Linear]
FC1:      [行切 Linear] → ReduceScatter → [RMSNorm + Quant](bs/TP，每卡不同 chunk) → AllGather(INT8) → [列切 Linear]
```

- **ReduceScatter**：沿 token 维（dim=0）切，hidden 维做 reduce 聚合。每卡从 `[bs, H/TP]`（partial sum）得到 `[bs/TP, H]`（值完整）。每卡拿到的是**不同 token chunk 上的完整 hidden**。
- **RMSNorm/Quant**：每卡只对 `bs/TP` 个 token 算，**TP 卡间不再重复**。
- **AllGather**：在下一个模块的列切 linear 的 matmul 前触发，把 `[bs/TP, H]` 聚合回 `[bs, H]`，喂给按输出维 TP 切的 matmul（标准 ColumnParallelLinear）。
- **INT8 量化**：因为 Quant 在 ReduceScatter 后做，AllGather 传输的是 INT8 张量，通信量减半。

> **关键代码边界**：FC1 的 reduce_scatter 在 `SequenceRowParallelOp.matmul_and_reduce` 的 else 分支（`linear_op.py:573-575`），**只有 `tensor_model_parallel_reduce_scatter`，没有 all_gather**。all_gather 在列并行侧 `SequenceColumnParallelOp.apply_impl`（`linear_op.py:436` 调 `maybe_all_gather_and_maybe_unpad`）。两者配合才构成完整 FC1 链路。

### 1.2 行切 linear 是哪些（FC1 接管的 RowParallel 注入点）

| prefix | 出现位置 | 说明 |
|--------|---------|------|
| `o_proj` | attention 输出 | 大多数 LLM |
| `out_proj` | attention 输出 | Qwen3 Next |
| `down_proj` | MLP 输出 / MoE routed expert 输出 / MoE 前几层 FFN 输出 | routed expert 本质就是 MLP |
| `attention.dense` | attention 输出 | Bailing |
| `wo_b` | attention 输出 | DeepSeek V4（`linear_op.py:685` 注释 `# attn output linear of v4`） |

> **MoE 中 shared expert 也本质是 down_proj，但 FC1 显式排除**（`linear_op.py:639, 678` `if "shared_expert" in prefix: return None`；更上层 `get_parallel_op:696-700` 对 `shared_experts`/`shared_expert` + `shared_expert_dp_enabled()` 也返回 None）。原因：shared expert 每 token 都算（无稀疏性），切 token 后输出需 all_gather 回完整，反而增加通信；保持 SP 不接管更优。

### 1.3 列切 linear 是哪些（all-gather 触发点）

| prefix | 出现位置 |
|--------|---------|
| `gate_up_proj` | MLP gate/up |
| `in_proj` / `conv1d` | Qwen3 Next gated deltanet |
| `qkv_proj` | attention QKV |
| `query_key_value` | Bailing |

每个模块的开头都是列切 linear，FC1 在其 matmul 前自动 all_gather（`linear_op.py:641-647` 前缀列表）。

### 1.4 `matmul_and_reduce` 的实际分支（四分支，不是三分支）

`SequenceRowParallelOp.matmul_and_reduce`（`linear_op.py:500-577`）实际有 **4 个分支**：

```
matmul_and_reduce(self, input_parallel, bias_)            # linear_op.py:500-577
├── :502-507  取 flash_comm_v1_enabled / mmrs_fusion（get_forward_context 失败则 False）
├── 分支A 标准 all_reduce        :511-513   if not flash_comm_v1_enabled:
│       quant_method.apply + tensor_model_parallel_all_reduce
├── :515-518  pad 处理（DSA-CP 下 o_proj/wo_b 跳过 pad，:516）
├── 分支B mmrs 融合(unquant)     :530-542   if mmrs_fusion and UnquantizedLinearMethod:
│       torch_npu.npu_mm_reduce_scatter_base(x, weight.t())
├── 分支C mmrs 融合(w8a8)        :544-572   elif mmrs_fusion and (AscendLinearMethod + AscendW8A8LinearMethod):
│       quantize → npu_mm_reduce_scatter_base → add(quant_bias, mul(deq_scale))
└── 分支D FC1 reduce_scatter     :573-575   else:
        quant_method.apply + tensor_model_parallel_reduce_scatter   ← 无 all_gather
```

**三个收益来源（按贡献排序）：**
1. **RMSNorm 计算量降为 1/TP** — ReduceScatter 后每卡只 `bs/TP` 个 token
2. **AllGather INT8 通信减半** — Quant 后传输
3. **MatMul+ReduceScatter 融合** — `npu_mm_reduce_scatter_base` 算子（分支 B/C）

**mmrs 触发条件的真相**：`matmul_and_reduce` 内部**没有 `tp_size<=8` 判断**。mmrs 是否走，取决于运行时上下文标志 `_EXTRA_CTX.mmrs_fusion` + `flash_comm_v1_enabled` + 量化类型。而 `mmrs_fusion` 这个标志本身，是在 `ascend_forward_context.py:113` 由 `mmrs_fusion = tp_world_size <= 8` 计算的（注释：`torch_npu.npu_mm_reduce_scatter_base` 不支持 tp_size>=16）。所以"tp<=8 才融合"是对的，但判断点在**标志计算处**，不在 `matmul_and_reduce` 内。

### 1.5 FC1 本体 vs 借用旁路 vs 独立开关（**任务核心，必须分清**）

`enable_sp()`（`utils.py:847-873`，语义 = `enable_flashcomm1`）是**用户侧主开关**，但它被多个特性共用为"前提条件"。**不要把"挂在 enable_sp 下"等同于"FC1 本体"**。按与 FC1 本体的关系分四类：

#### 第一类：FC1 本体（开 `enable_flashcomm1` 即生效，**这才是需要适配开发的**）

| 组件 | 位置 | 作用 |
|------|------|------|
| 列并行 Op | `linear_op.py:423-445` `SequenceColumnParallelOp` | matmul 前 `maybe_all_gather_and_maybe_unpad` |
| 行并行 Op | `linear_op.py:476-498` `SequenceRowParallelOp` + `matmul_and_reduce:500-577` | matmul 后 reduce_scatter / mmrs 融合 |
| 图模式 pad 逻辑 | `register_custom_ops.py:40-70` `_maybe_all_gather_and_maybe_unpad_impl`、`:73-105` `_maybe_pad_and_reduce_impl`、`:23-37` `_maybe_chunk_residual_impl` | graph 模式下 pad/unpad/residual chunk |
| 运行时标志+pad_size | `ascend_forward_context.py:122-142`（V1）、`platform.py:970-975`（V2） | `flash_comm_v1_enabled`/`mmrs_fusion`/`pad_size` |
| Op 派发 | `linear_op.py:628-691` `_get_column_parallel_op`/`_get_row_parallel_op` | `if enable_sp():` 分支注入 Sequence*Op |
| cudagraph 对齐 | `platform.py:547-562` | SP 下 capture size 需能被 TP 整除 |
| **SP Pass 桥** | `model_runner_v1.py:5003-5011` `update_pass_config` | 编译期把 `pass_config.enable_sp = enable_sp()`，拉起 SP Inductor Pass |

> ⚠️ **SP Pass 桥是 FC1 本体的一部分**（注释 `TODO: remove it when flash_comm1 is removed`）。开 FC1 会同时拉起 SP Inductor Pass（`graph_fusion_pass_manager.py:74`）。对 graph 模式非 VL 稠密模型，CustomOp 已把 all_reduce 融进 `matmul_and_reduce`，Pass 的 `all_reduce+RMSNorm` pattern 匹配不到 → Pass 实为 no-op，不冲突；对 VL 模型，CustomOp 在 layer-0 attn 让位（`linear_op.py:435`），由 Pass 接管。**这层耦合是 §8 失效方案必须处理的**。

#### 第二类：借 `enable_sp()` 作前提的独立特性（**不是 FC1 本体**）

| 特性 | 独立入口 | 借用方式 | 代码位置 | 与 FC1 本体关系 |
|------|---------|---------|---------|----------------|
| **DSA-CP** | `enable_dsa_cp()` `utils.py:1344-1365` | `= dsa_cp_enable and enable_sp()`，不满足 raise ValueError | `ShardedCP*Op` `linear_op.py:586-625`；派发 `:631,:666` | **完全独立**。用 fake comm group（`SimpleNamespace(world_size=1,...)` `:590,:613`）bypass TP，`reduce_results=False`（`:606`），**不与 FC1 共用 reduce_scatter 基础设施** |
| **shared_expert_dp** | `ascend_config.enable_shared_expert_dp` | 反噬：`enable_sp(enable_shared_expert_dp=True)` 把 `_ENABLE_SP` 拉成 True（`utils.py:869-871`） | `ascend_config.py:113-121`；`linear_op.py:696-700` | 独立 DP 化特性，强制开 FC1 开关 |
| **310p GDN** | 无独立开关 | `if not enable_sp():` 做切片分叉 | `gdn_310.py:267,475,480` | 借开关决定 mixed_qkv/core_attn_out 是否切片 |
| **PCP** | `prefill_context_parallel_size` | `>1 and enable_sp()` 对齐校验 | `ascend_config.py:123`；`prepare_finalize.py` PCP 分支 | 借前提做 max_num_batched_tokens 对齐，通信用独立 `pcp_group` |

#### 第三类：独立第二开关的互补路径

| 特性 | 开关 | 机制 | 与 FC1 关系 |
|------|------|------|------------|
| **SP Pass (VL 图模式)** | `enable_sp_by_pass()` `utils.py:843-844` ← `pass_config.enable_sp`（`ascend_config.py:260-264` = `not enforce_eager and pass_config.enable_sp`） | Inductor `PatternMatcherPass` 改写 `all_reduce+RMSNorm → reduce_scatter+RMSNorm+all_gather`（`sequence_parallelism.py:56-184`） | **互补**。注意：`update_pass_config`（第一类桥）会在编译期把 `pass_config.enable_sp` 覆写为 `enable_sp()`，故开 FC1 时 `enable_sp_by_pass()` 也变 True |

#### 第四类：完全不经过 `enable_sp()`

| 特性 | 开关 | 代码 |
|------|------|------|
| **MoE SP (routed expert 序列切分)** | 上游 `parallel_config.use_sequence_parallel_moe` | `deepseek_v4.py:367` `is_sequence_parallel = use_sequence_parallel_moe`；入口 `:460-461` `sequence_parallel_chunk`；出口 `:494-496` `tensor_model_parallel_all_gather` |

> ⚠️ **不要混淆两层 MoE 通信机制**：deepseek_v4 自身的 MoE SP（`use_sequence_parallel_moe`，第四类）走 chunk+all_gather，**不调 `enable_sp()`**；而 `prepare_finalize.py:358,483` 的 `if enable_sp() or enable_sp_by_pass():` 是**另一套**——FC1/Pass 借给 MoE 的 EP-group 通信路径选择。两层不同机制，混讲是常见错误。

> ⚠️ **关于 `use_sequence_parallel_moe` 被 disable 的旧说法**：`platform.py:647-650` 注释写 `# TODO: this is a tricky way to disable use_sequence_parallel_moe in vllm.`，但实际代码只在 `not pass_config.enable_sp` 时改 `all2all_backend`，**并未真正 disable `use_sequence_parallel_moe`**。其值由上游 vllm config 决定，vllm-ascend 内未 override。

### 1.6 DSA-CP 判定条件的真相（不是 `is_ds_v32`）

`enable_dsa_cp()`（`utils.py:1344-1365`，`@lru_cache`）的实际条件：
1. 模型有 indexer：`hasattr(hf_text_config, "index_topk")`（`:1349-1352`）— 即 **DSv3.2 / DSv4 等带 DSA 的模型**，不是硬编码 `is_ds_v32`；
2. `additional_config["enable_dsa_cp"]` 为 True（`:1357-1359`）；
3. `enable_sp()` 为 True，否则 `:1361-1364` raise ValueError。
返回 `dsa_cp_enable and enable_sp()`。

- **DSA-CP 本质**：让 attention 内的 linear（`q_b_proj`/`kv_b_proj`/`o_proj`/`wo_b`）TP=1（类似 sglang DP-attention）。要求 token 已被均分到不同卡上。
- **实现**：`ShardedCPColumnParallelOp`/`ShardedCPRowParallelOp` 用 fake comm group "bypass tp logic"，Linear 以为 world_size=1，不切分不 AllReduce。
- **为什么 token 已均分**：DSA-CP 复用 FC1 的 ReduceScatter 把 bs→bs/TP，attention 内部每卡算不同 token chunk。
- **优先级**：DSA-CP > FC1（`linear_op.py:631,:666`）。激活 DSA-CP 后，attention 内 linear 走 ShardedCP*Op（TP=1），MLP 内 linear 仍走 FC1。

---

## 2. 关键事实（已核实源码）

| 事实 | 位置 | 备注 |
|------|------|------|
| Env var `VLLM_ASCEND_ENABLE_FLASHCOMM1` | `envs.py:75`（`:74` 是 DEPRECATED 注释，指向 `additional_config.enable_flashcomm1`） | 默认 "0"。**无旧名 `VLLM_ASCEND_ENABLE_FLASHCOMM`（无1）兼容代码**，全仓零匹配 |
| `enable_flashcomm1` config 取值 | `ascend_config.py:83-88` | 从 `additional_config["enable_flashcomm1"]` 或 env 取 |
| `enable_sp()` 入口 | `utils.py:847-873` | FC1 主开关；签名 `enable_sp(vllm_config=None, enable_shared_expert_dp=False)`；读 `enable_flashcomm1`；**不查 `is_ds_v32`** |
| `enable_sp_by_pass()` | `utils.py:843-844` + `ascend_config.py:260-264` | `= not enforce_eager and pass_config.enable_sp`；VL SP Pass 开关 |
| `enable_dsa_cp()` | `utils.py:1344-1365` | `hasattr(index_topk)` + `enable_dsa_cp` config + `enable_sp()`；`@lru_cache` |
| `enable_dsa_cp_with_layer_shard()` | `utils.py:1368-1379` | `enable_dsa_cp() and kv_role=="kv_producer"`（P-side） |
| `enable_dsa_cp_with_o_proj_tp()` | `utils.py:1382-1394` | `enable_dsa_cp() and (kv_transfer_config is None or kv_role=="kv_both")` |
| shared_expert_dp 自动开启 | `utils.py:869-871`（触发 `ascend_config.py:120-121`） | `enable_shared_expert_dp` 需 `enable_expert_parallel and tp>1` |
| `shared_expert_dp_enabled()` | `utils.py:877-878` | `= enable_shared_expert_dp or enable_sp() or enable_sp_by_pass()` |
| V1 FC1 激活（三分支） | `ascend_forward_context.py:122-132` | MoE(:125 无阈值)/draft(:130 强制False)/dense主(:132 有1000阈值) |
| V2 FC1 激活 | `platform.py:970-975`（gate `:940-941`） | MoE(:972)/dense(:975 有1000阈值)；V2 下 mmrs 恒 True(:970) |
| `mmrs_fusion` 标志计算 | `ascend_forward_context.py:113`（V1）/ `platform.py:970`（V2） | V1: `tp_world_size <= 8`；MoE 分支覆盖为 False(:126) |
| 运行时标志赋值 | `ascend_forward_context.py:133-142` | `pad_size = (tp - num_tokens % tp) % tp` |
| `_EXTRA_CTX` 对象 | `ascend_forward_context.py:322`(类)/`:381`(实例)/`:325-349`(extra_attrs) | 含 `flash_comm_v1_enabled`/`mmrs_fusion`/`pad_size`，§3.1 自检脚本依赖成立 |
| SP Pass 桥 | `model_runner_v1.py:5003-5011`（调用 `:4788`） | 编译期 `pass_config.enable_sp = enable_sp()`；`TODO: remove it when flash_comm1 is removed` |
| 列并行 Op | `linear_op.py:423` `SequenceColumnParallelOp` | matmul 前 `maybe_all_gather_and_maybe_unpad`（`:436`） |
| 行并行 Op | `linear_op.py:476` `SequenceRowParallelOp` | `matmul_and_reduce` `:500-577` |
| DSA-CP 列并行 Op | `linear_op.py:609` `ShardedCPColumnParallelOp` | fake comm group（`:610-613`） |
| DSA-CP 行并行 Op | `linear_op.py:586` `ShardedCPRowParallelOp` | fake comm group + `reduce_results=False`（`:604-606`） |
| Op 分发 | `linear_op.py:628` `_get_column_parallel_op` / `:655` `_get_row_parallel_op` | |
| 三个 custom op impl | `register_custom_ops.py:40`/`:73`/`:159`（impl 定义）；注册在 `:228-234`/`:236-242`/`:268-274` | 注意 impl 行 ≠ 注册行 |
| DSA-CP o_proj/wo_b 不 pad | `linear_op.py:516` | `enable_dsa_cp() and ("o_proj" in prefix or "wo_b" in prefix)` |
| SP Inductor Pass | `compilation/passes/sequence_parallelism.py:187` / `sequence_parallelism_moe.py` | VL 走这条；门控 `pass_config.enable_sp`（`graph_fusion_pass_manager.py:74`） |
| 类名映射注入 Ascend 线性层 | `utils.py:684-712` `REGISTERED_ASCEND_OPS` | 上游模型无需改文件，靠类名映射注入 |
| 线性层回退路径 | `linear.py:201-204` | `custom_op is None` → `super().forward()` = 标准 TP linear |

### 2.1 前缀匹配表（精确）

**列并行**（`linear_op.py:641-647`，`in` 子串匹配）进入 `SequenceColumnParallelOp`：
```
gate_up_proj        # 大多数 LLM 的 MLP gate/up
in_proj             # Qwen3 Next gated deltanet
qkv_proj            # 大多数 LLM 的 QKV
conv1d              # Qwen3 Next gated deltanet
query_key_value     # Bailing
```

**行并行**（`linear_op.py:680-686`，`in` 子串匹配）进入 `SequenceRowParallelOp`：
```
o_proj              # 大多数 LLM 的 attn 输出
out_proj            # Qwen3 Next
down_proj           # 大多数 LLM 的 MLP down / MoE routed expert down / MoE 前几层 FFN
attention.dense     # Bailing
wo_b                # DeepSeek V4 attn 输出
```

> ⚠️ 行并行列表有 **5 项**，`wo_b` 易漏。匹配是 `in` 子串匹配，新增前缀时避免是已有前缀的子串造成误命中。

### 2.2 优先级（高 → 低，会拦截 FC1）

实际代码判定顺序（`linear_op.py:628-691`，命中即 return）：

**列并行** `_get_column_parallel_op`（`:631-652`）：
```
1. DSA-CP    — q_b_proj/kv_b_proj (enable_dsa_cp)         → ShardedCPColumnParallelOp (TP=1)
2. MLP TP    — gate_up_proj + mlp_tp_enable + not moe      → MLPColumnParallelOp
3. FC2       — qkv_proj/conv1d/query_key_value (flashcomm2_oshard_enable) → Flashcomm2OshardQKVParallelOp
4. FC1       — gate_up_proj/in_proj/qkv_proj/conv1d/query_key_value (enable_sp)
```

**行并行** `_get_row_parallel_op`（`:666-689`）：
```
1. DSA-CP    — o_proj (enable_dsa_cp_with_layer_shard)     → ShardedCPRowParallelOp (TP=1)
2. MLP TP    — down_proj + mlp_tp_enable + not moe          → MLPRowParallelOp
3. OProj TP  — o_proj + oproj_tp_enable                    → OProjRowParallelOp
4. MatmulAllReduce — matmul_allreduce_enable                → MatmulAllreduceRowParallelOp
5. FC2       — o_proj/out_proj (flashcomm2_enable)          → Flashcomm2OProjRowParallelOp
6. FC1       — o_proj/out_proj/down_proj/attention.dense/wo_b (enable_sp)
```

> 高优先级 op 会拦截 FC1。若 FC1 不生效，先确认 1-5 是否激活。
> DSA-CP 高优先级是设计意图：attention 内 linear TP=1 后，FC1 的 reduce_scatter/all_gather 在 attention 内已无意义；但 MLP 仍走 FC1。
> 注意：DSA-CP 列并行条件是 `q_b_proj/kv_b_proj`（`:631`），行并行条件才是 `o_proj`（`:666`）—— 不要笼统说"DSA-CP 命中 o_proj/qkv"。

### 2.3 显式排除

- `shared_expert` 前缀（`linear_op.py:639, 678`）→ FC1 不接管；上层 `get_parallel_op:696-700` 对 `shared_experts`+`shared_expert_dp_enabled()` 也返回 None
- Draft/MTP 模型 → `ascend_forward_context.py:127-130` 路径强制 `flash_comm_v1_enabled = False`
- `tp_size == 1` → FC1 无意义（`linear_op.py:492` apply_impl 直接走无 reduce 路径）
- `num_tokens <= 1000`（dense 主模型）→ `:132` 不激活；MoE 无此阈值（`:125`）

---

## 3. 决策树：模型能否开 FC1

```
模型使用 Ascend 线性层？(靠 REGISTERED_ASCEND_OPS 类名映射注入, utils.py:684-712)
  ├── 否 → 改用 Ascend*Linear + 传 prefix（§4.1）
  └── 是 → prefix 在 §2.1 列表？
            ├── 否 → 在 linear_op.py 加前缀（§4.2）
            └── 是 → 高优先级 op 拦截？（§2.2）
                      ├── 是 → 评估是否禁用拦截 op
                      └── 否 → 是 VL 模型？
                                ├── 是 → 走 SP Pass（§7），CustomOp FC1 在 layer-0 attn 让位
                                └── 否 → 是 Draft/MTP？
                                          ├── 是 → 强制关闭 FC1（:130）
                                          └── 否 → 需特殊 patch？（§4.3）
                                                    ├── 是 → 编写 patch
                                                    └── 否 → ✓ FC1 就绪
```

### 3.1 一键自检脚本

在模型加载后任意位置插入（依赖 `_EXTRA_CTX`，已确认存在 `ascend_forward_context.py:381`）：
```python
from vllm_ascend.ascend_forward_context import _EXTRA_CTX
import torch.distributed as dist
print(
    f"[FC1 check] rank={dist.get_rank()} "
    f"fc1={_EXTRA_CTX.flash_comm_v1_enabled} "
    f"mmrs={_EXTRA_CTX.mmrs_fusion} "
    f"pad={_EXTRA_CTX.pad_size} "
    f"tp={dist.get_world_size()}"
)
```
若 `fc1=False` 且 `tp>1`，按 §6 排查。注意 MoE 模型无 1000 阈值，dense 主模型需 `num_tokens>1000`。

---

## 4. 适配 Playbook

### 4.1 新模型 — 标准命名（0 改动）

大多数模型（含 Qwen3 稠密）复用上游 vllm 模型文件，靠 `REGISTERED_ASCEND_OPS`（`utils.py:684-712`）类名映射自动注入 Ascend 线性层。只要上游命名落在 §2.1 列表内，**零代码改动**，设 `enable_flashcomm1=1` 即可。

```python
# 上游模型代码（无需改），命名已命中：
self.qkv_proj = QKVParallelLinear(..., prefix=f"{prefix}.qkv_proj")    # 映射→AscendQKVParallelLinear
self.o_proj = RowParallelLinear(..., prefix=f"{prefix}.o_proj")        # 映射→AscendRowParallelLinear
self.gate_up_proj = MergedColumnParallelLinear(..., prefix=f"{prefix}.gate_up_proj")
self.down_proj = RowParallelLinear(..., prefix=f"{prefix}.down_proj")
```

### 4.2 非标准命名 — 加前缀

编辑 `vllm_ascend/ops/linear_op.py`：

```python
# _get_column_parallel_op 内（:641 附近）
sp_column_prefix = [
    "gate_up_proj", "in_proj", "qkv_proj", "conv1d", "query_key_value",
    "my_custom_col_prefix",  # 新增
]

# _get_row_parallel_op 内（:680 附近）
sp_row_prefixes = [
    "o_proj", "out_proj", "down_proj", "attention.dense", "wo_b",
    "my_custom_row_prefix",  # 新增
]
```

> prefix 用 `in` 子串匹配，避免新前缀是已有前缀的子串造成误命中。

### 4.3 特殊 Patch 场景（**按模型区分，不要套用**）

| 场景 | 适用模型 | 现象 | 处理 | 参考 |
|------|---------|------|------|------|
| Layer0 attn 输出 buffer 缩小 | **仅 Qwen3-5（gated deltanet）** | 预分配 buffer shape 不对崩溃 | 缩小为 `ceil(seq/TP) × dim` | `patch/worker/patch_qwen3_5.py:104-112` |
| 残差/DeepStack chunk | Qwen3-VL | residual shape 不匹配 | `maybe_chunk_residual` + chunk by tp_size | `patch/worker/patch_qwen3vl.py`；`register_custom_ops.py:23-37` |
| MLA attention | 全量 MLA 模型 | — | 调 `need_gather_q_kv` | `ops/mla.py` |
| MTP/Spec Decode | draft 输出 NaN | 最终层未 all_gather | 最终层 `tensor_model_parallel_all_gather` | `models/deepseek_v4_mtp.py`；`spec_decode/llm_base_proposer.py:2029+` |
| MoE routed expert | MoE | router 输入不对 | `sequence_parallel_chunk` 入口 + 出口 all_gather | `models/deepseek_v4.py:460-496`，`ops/prepare_finalize.py` |

> ⚠️ **Layer0 buffer patch 是 Qwen3-5 专属**（它 attention 输出写进预分配 buffer，FC1 下 Layer0 输出被切到 bs/TP 所以 buffer 要缩小）。**Qwen3 稠密 `Qwen3DecoderLayer.forward` 直接 return hidden_states，无预分配 buffer，不需要此 patch**。把 Qwen3-5 的 patch 套到 Qwen3 稠密会引入无谓改动。`patch_qwen3_5` 仅在 `not is_310p()` 时导入（`patch/worker/__init__.py:44-45`）。

### 4.4 MoE 模型适配完整步骤

```python
# 1. 标记 is_sequence_parallel（读上游 config，不依赖 enable_sp）
is_sequence_parallel = parallel_config.use_sequence_parallel_moe   # deepseek_v4.py:367

# 2. Forward 入口 chunk
hidden_states = sequence_parallel_chunk(hidden_states)             # :460-461

# 3. Router 前 all_gather（prepare_finalize.py 自动处理）
# 4. MoE 计算 ...（routed expert 的 down_proj 自动走 FC1，shared_expert 自动排除）
# 5. 出口 all_gather
hidden_states = tensor_model_parallel_all_gather(final_hidden_states, 0)  # :494-496
```

### 4.5 适配的解耦原则（任务一 1.3）

1. **优先零改动**：靠 `REGISTERED_ASCEND_OPS` 类名映射 + 标准 prefix 命名，不碰 `linear_op.py`。
2. **必须改前缀时**：只往 `sp_column_prefix`/`sp_row_prefixes` 列表追加，不动 Op 类、不动派发优先级、不动其他特性分支。
3. **必须加 patch 时**：放 `patch/worker/patch_<model>.py`，按 `__init__.py` 既有模式注册，gate 在模型类型/硬件类型，不污染通用路径。
4. **复用公共接口**：reduce_scatter 用 `tensor_model_parallel_reduce_scatter`、all_gather 用 `maybe_all_gather_and_maybe_unpad`、residual chunk 用 `maybe_chunk_residual`，**不要自己构造通信调用**。
5. **不破坏其他开关**：DSA-CP/shared_expert_dp/SP Pass 的优先级分支（§2.2 第 1-3/5 位）保持原样，新适配只落在 FC1 分支（最低优先级），天然不拦截别人。

---

## 5. 运行时验证 — 确认 FC1 真在跑

### 5.1 日志检查

```bash
grep -E "flash_comm_v1|mmrs_fusion|enable_sp" <VLLM_SERVE_LOG>
```
应看到 `flash_comm_v1_enabled=True`。

### 5.2 运行时 print

见 §3.1 自检脚本。

### 5.3 算子级确认

开 `VLLM_ASCEND_LOG_LEVEL=DEBUG`，搜：
```
SequenceColumnParallelOp / SequenceRowParallelOp
maybe_pad_and_reduce / maybe_all_gather_and_maybe_unpad
```
若看不到，说明被高优先级 op 拦截（看 §2.2）。VL 模型则搜 SP Pass 的 `Replaced N patterns` 日志（`sequence_parallelism.py:214`）。

### 5.4 性能对比

```bash
# 不开 FC1（注意 graph 模式需同时断 Pass 桥，见 §8）
VLLM_ASCEND_ENABLE_FLASHCOMM1=0 vllm serve ...

# 开 FC1
VLLM_ASCEND_ENABLE_FLASHCOMM1=1 vllm serve ...
```
对比 decode 阶段 TPOT；prefill 阶段 TTFT 应无明显劣化（token 数足够时）。**on/off 对比必须确保 §8 的失效是完整的，否则 graph 模式下 Pass 会接管导致"看似关了实际没关"**。

---

## 6. 排查矩阵

| 现象 | 排查 | 原因 | 解决 |
|------|------|------|------|
| `flash_comm_v1_enabled=False` | §3.1 自检 | env 未设 / dense 模型 token<1000 / tp=1 / draft 模型 | 设 env / 增 batch / 增 TP / 关 draft |
| Layer0 崩溃 | shape 不匹配 | **仅 Qwen3-5** attn 输出 buffer 未缩小 | 加 patch（§4.3，Qwen3-5 专属） |
| residual shape mismatch | 残差未 chunk | DeepStack/residual 路径 | `maybe_chunk_residual` / chunk by tp_size |
| MTP 输出 NaN | draft 最终层 | 未 all_gather | 加 `tensor_model_parallel_all_gather` |
| 性能反而劣化 | 并发不够 | dense token 数低于 1000 阈值 | 增 batch 或降阈值 |
| `npu_mm_reduce_scatter_base` 报错 | tp>8 | `mmrs_fusion` 标志为 False（`:113`） | 不用管，FC1 仍跑（走分支D reduce_scatter），只是没融合 |
| `SequenceRowParallelOp` 没出现 | 被拦截 | §2.2 高优先级 op 激活 | 关掉拦截 op 或换 prefix |
| DSA-CP 没生效 | 模型无 indexer | `enable_dsa_cp()` 要求 `hasattr(index_topk)` | 仅 DSv3.2/DSv4 等带 DSA 模型支持 |
| on/off 性能无差异 | graph 模式 Pass 接管 | §8 失效不完整，Pass 仍在跑 | 按 §8.1 graph 变体断 Pass 桥 |

---

## 7. FC1 vs FC2 vs SP Pass vs DSA-CP 选型

| 维度 | FC1 (CustomOp) | FC2 (OShard) | SP Pass (Inductor) | DSA-CP |
|------|---------------|--------------|-------------------|--------|
| 适用模型 | 非 VL Dense/MoE | 大 EP MoE（DeepSeek V3.x） | VL Dense/MoE | 带 indexer 的 DS V3.2/V4 |
| 切分对象 | seq_len 维 | expert 维 + seq | seq 维 | seq 维（attention 内 TP=1） |
| 模式 | eager + graph | graph | graph only（`not enforce_eager`） | graph |
| 核心机制 | LinearOp 前缀注册 | OShard manager | 图模式 pattern 替换 | fake comm group (TP=1) |
| 专用融合 | `npu_mm_reduce_scatter_base` (tp≤8) | OShard 算子 | 无 | 复用 FC1 融合 |
| 触发开关 | `enable_sp()`=`enable_flashcomm1` | `flashcomm2_enable()` | `pass_config.enable_sp`（被 `update_pass_config` 桥接到 `enable_sp()`） | `enable_dsa_cp()`（借 `enable_sp()` 前提） |
| 互斥关系 | 与 FC2 互斥（行并行 FC2 优先 :674） | 与 FC1 互斥 | 与 CustomOp FC1 互补（VL layer-0 让位） | 高优先级拦截 FC1（attention 内） |

选型规则：
- **非 VL Dense** → FC1
- **非 VL MoE** → FC1 + `use_sequence_parallel_moe=True`（MoE SP 第四类，独立于 enable_sp）
- **VL 模型** → SP Pass（开 FC1 即经 `update_pass_config` 自动拉起）
- **大 EP MoE（DeepSeek V3.2 等）** → FC2（优先级高于 FC1，自动接管）+ DSA-CP（attention DP 化）
- **带 indexer 的 DS V3.2/V4 attention** → DSA-CP（需 `enable_dsa_cp` config + `enable_sp`，自动随 enable_sp 前提激活）

---

## 8. 让 FC1 失效（disable）方案

> ⚠️ **核心坑**：FC1 与 SP Pass 经 `update_pass_config`（`model_runner_v1.py:5003-5011`）耦合。**eager 模式**下 Pass 不跑，改 4 行即可；**graph 模式**下若不断 Pass 桥，Pass 会接管把 `all_reduce` 重写成 `reduce_scatter+all_gather`，SP 并未真正关闭，on/off 对比被污染。

### 8.1 外科式失效（推荐，零副作用，保留 DSA-CP/shared_expert_dp/310p GDN/PCP）

只关 FC1 本体。`enable_sp()` 仍返回 True，故 DSA-CP / shared_expert_dp / 310p GDN / PCP 全部不受影响。

**eager 模式（4 行，Pass 不参与）：**

| 位置 | 当前代码 | 修改 | 原因 |
|------|---------|------|------|
| `linear_op.py:638` | `if enable_sp():`（列并行 FC1 入口） | `if False:` | 屏蔽后 gate_up/qkv 回退标准 ColumnParallelLinear（`linear.py:201-204` super().forward） |
| `linear_op.py:677` | `if enable_sp():`（行并行 FC1 入口） | `if False:` | 屏蔽后 o_proj/down_proj 回退标准 RowParallelLinear + AllReduce |
| `ascend_forward_context.py:132` | `flash_comm_v1_enabled = enable_sp(...) and ... num_tokens > 1000` | `flash_comm_v1_enabled = False` | V1 dense 主模型标志；堵 Eagle/patch 的 FC1 分支（`llm_base_proposer.py:2029+`、`patch_qwen3_5.py:104`） |
| `platform.py:975` | 同上 | `flash_comm_v1_enabled = False` | V2 dense 路径标志（gate `:940-941`） |

> 若目标含 MoE，再堵 `ascend_forward_context.py:125` 和 `platform.py:972`（MoE 分支，无 1000 阈值）。

**graph 模式（eager 4 行 + 断 Pass 桥 1 行）：**

| 位置 | 当前代码 | 修改 | 原因 |
|------|---------|------|------|
| `model_runner_v1.py:5008` | `model_runner.compilation_config.pass_config.enable_sp = enable_sp(model_runner.vllm_config)` | `model_runner.compilation_config.pass_config.enable_sp = False` | 不断则 SP Pass（`sequence_parallelism.py:187`）注册并改写 all_reduce→reduce_scatter+all_gather，SP 仍跑 |

> 断 Pass 桥只影响 graph 模式 SP 改写，不影响 DSA-CP（用 ShardedCP*Op CustomOp）、shared_expert_dp、310p GDN、PCP（都不依赖 SP Pass）。

**回退路径已确认**（`linear_op.py:694-723` `get_parallel_op`）：Op 分发返回 None → `custom_op=None` → `AscendQKVParallelLinear.forward`（`linear.py:201-204`）走 `super().forward()` = 标准 TP linear + AllReduce。

### 8.2 单点全局失效（简单但有副作用）

| 位置 | 当前代码 | 修改 | 原因 |
|------|---------|------|------|
| `utils.py:847-873` | `def enable_sp(...): ...` | 直接 `return False` | FC1/DSA-CP/shared_expert_dp/310p GDN/PCP 统一开关 |

**副作用**（逐个核实，均真依赖 enable_sp）：

| 受影响特性 | 位置 | 影响程度 |
|-----------|------|---------|
| DSA-CP | `utils.py:1344-1365`（`:1361-1364` 还会 raise ValueError） | **严重** — DS V3.2/V4 推理退化 |
| shared_expert_dp 自动开启 | `utils.py:869-871` | 中等（`if not _ENABLE_SP` 逻辑被绕过） |
| 310p GDN SP 路径 | `gdn_310.py:267,475,480` | 仅 310P 卡 |
| PCP+SP 联合判定 | `ascend_config.py:123` | 边缘场景 |
| 线性层 unique_prefix 注册 | `linear.py:287` | 中等 |
| SP Pass 桥 | `model_runner_v1.py:5008`（经 enable_sp） | graph 模式 Pass 也关 |

> 不推荐方案 B，除非确认 DSA-CP/shared_expert_dp 不在目标场景。

### 8.3 完整物理移除（仅列出，不推荐）

| 文件 | 行号 | 内容 |
|------|------|------|
| `ops/linear_op.py` | 423-445 | `SequenceColumnParallelOp` 类 |
| `ops/linear_op.py` | 476-577 | `SequenceRowParallelOp` 类 + `matmul_and_reduce` |
| `ops/linear_op.py` | 503 | FC1 guard（`matmul_and_reduce` 内 try/except） |
| `ops/linear_op.py` | 641-647, 680-686 | 前缀列表 |
| `ops/register_custom_ops.py` | 40-105, 159-166, 228-274 | 三个 custom op impl + 注册 |
| `ascend_forward_context.py` | 112-142 | 运行时标志 |
| `platform.py` | 970-975 | V2 路径标志 |
| `model_runner_v1.py` | 5003-5011 | SP Pass 桥 `update_pass_config` |
| `patch/worker/patch_qwen3_5.py` | 104-112 | Layer0 patch（Qwen3-5 专属） |
| `spec_decode/llm_base_proposer.py` | 2029-2056 | Eagle FC1 分支 |
| `ops/linear.py` | 287 | 线性层 SP 分支 |
| `envs.py` | 75 | env var 定义 |

> 注意：`linear_op.py:366,460` 是 **FC2** 的 guard（`Flashcomm2OProjRowParallelOp`/`Flashcomm2OshardQKVParallelOp`），不是 FC1，物理移除 FC1 时不要误删。

### 8.4 失效正确性自检

失效后跑 §3.1 自检脚本，应得 `fc1=False`。再开 `VLLM_ASCEND_LOG_LEVEL=DEBUG` 确认：
- eager：日志无 `SequenceRowParallelOp` / `maybe_pad_and_reduce`。
- graph：日志无 SP Pass 的 `Replaced N patterns`（N 应为 0 或 Pass 未注册）。

---

## 9. 已知支持模型

| 模型 | 类型 | FC1 方式 | 特殊处理 |
|------|------|---------|---------|
| Qwen3 Dense | Dense | CustomOp + mmrs 融合 | 标准前缀，零改动 |
| Qwen3 W8A8/W4A8 | Dense | CustomOp | 量化融合（分支C） |
| Qwen3-5 | Dense(gated deltanet) | CustomOp | Layer0 buffer patch（`patch_qwen3_5.py:104-112`，专属） |
| Qwen3 Next | Dense | CustomOp | `in_proj`/`conv1d`/`out_proj` |
| Qwen3-VL | VL MoE | SP Pass | DeepStack chunk |
| GLM5 | Dense | CustomOp | 标准前缀 |
| DeepSeek V4 | MoE | CustomOp | MoE SP（`use_sequence_parallel_moe`）+ MTP all_gather + `wo_b` |
| DeepSeek V3.2 | MoE | FC2 + DSA-CP | 大 EP 场景；attention 走 DSA-CP（hasattr index_topk） |
| Bailing | Dense/MoE | CustomOp | `query_key_value`/`attention.dense` |

---

## 10. 关键文件索引（速查）

| 文件 | 关键符号 |
|------|---------|
| `envs.py:75` | `VLLM_ASCEND_ENABLE_FLASHCOMM1` |
| `ascend_config.py:83-88,260-264` | `enable_flashcomm1` / `enable_sp_by_pass` |
| `utils.py:847` | `enable_sp()` |
| `utils.py:843,877` | `enable_sp_by_pass()` / `shared_expert_dp_enabled()` |
| `utils.py:1344,1368,1382` | `enable_dsa_cp()` / `_with_layer_shard` / `_with_o_proj_tp` |
| `utils.py:684-712` | `REGISTERED_ASCEND_OPS` 类名映射 |
| `ascend_forward_context.py:112-142` | V1 FC1 标志/pad_size |
| `platform.py:547-562,970-975` | cudagraph 对齐 / V2 FC1 标志 |
| `model_runner_v1.py:4788,5003-5011` | SP Pass 桥 `update_pass_config` |
| `ops/register_custom_ops.py:40,73,159` | 三个 custom op impl |
| `ops/linear_op.py:423,476,586,609,628,655` | 4 个 Op 类 + 分发 |
| `ops/linear_op.py:500-577` | `matmul_and_reduce` 四分支 |
| `ops/linear.py:201-204,287` | 线性层回退路径 / unique_prefix |
| `ops/mla.py` | MLA 特殊处理 |
| `ops/prepare_finalize.py:358,483` | MoE EP-group 通信路径选择 |
| `compilation/passes/sequence_parallelism*.py` | SP Inductor Pass（VL 用） |
| `compilation/graph_fusion_pass_manager.py:74-79` | Pass 注册门控 |
| `patch/worker/patch_qwen3_5.py:104-112` | Layer0 patch（Qwen3-5 专属） |
| `models/deepseek_v4.py:367,460-496` | MoE + MTP FC1 范例 |

---

## 11. 参考

- PR #2802 — FC1 在 Qwen Dense 首次实现（rjg-lyh）
- PR #3085 — MoE/Dense 统一重构（weijinqian_v1）
- `docs/source/user_guide/feature_guide/sequence_parallelism.md`
- Megatron-LM Sequence Parallelism 论文
- SGLang DP-Attention（DSA-CP 的概念原型）
- release_notes PR #9064 — 配置从 env 迁移到 `additional_config.enable_flashcomm1`
