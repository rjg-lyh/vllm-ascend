# FC1 Adaptation Catalog — 现有适配方式索引

按"模块/场景"分类，记录 code-base 中已有的 FC1 适配代码位置、模式、原因。
适配新模型时先查此目录，复用同类模式。

> 行号核实于 2026-07。标 `需复核` 者为本技能未直接读源码逐行确认、仅作定位线索，
> 使用前请自行 `grep` 确认。**适配时只信机制描述与函数名，行号会漂移。**

---

## 1. Layer 0 Attention 输出 buffer 缩小（**Qwen3-5 专属**）

**场景**：Qwen3-5（gated deltanet）的 attention 输出写进预分配 buffer。FC1 下 Layer0 输出被切到 `bs/TP`，buffer 必须预缩小，否则 shape 不匹配。

**位置**：`vllm_ascend/patch/worker/patch_qwen3_5.py:104-112`（仅在 `not is_310p()` 时导入，`patch/worker/__init__.py:44-45`）

**模式**：
```python
if self.layer_idx == 0 and _EXTRA_CTX.flash_comm_v1_enabled:
    tp_size = get_tensor_model_parallel_world_size()
    n_out = (hidden_states.shape[0] + tp_size - 1) // tp_size  # ceil(bs/TP)
    hidden_dim = hidden_states.shape[-1]
    self_attention_output = torch.empty((n_out, hidden_dim), ...)
```

**适用模型**：**仅 Qwen3-5**。⚠️ Qwen3 稠密 `Qwen3DecoderLayer.forward` 直接 return hidden_states，无预分配 buffer，**不需要此 patch**，不要套用。

---

## 2. DeepStack / Residual Chunk

**场景**：Qwen3-VL 的 DeepStack 把多层 input embed 拼成 `deepstack_input_embeds`，FC1 后每卡只持有 `bs/TP` token，需把 embeds 也 chunk 到 `bs/TP`。

**位置**：`vllm_ascend/patch/worker/patch_qwen3vl.py`（具体行 `需复核`）；底层用 `register_custom_ops.py:23-37` `_maybe_chunk_residual_impl`。

**模式**：`maybe_chunk_residual(reduce_scatter, residual)` 在 SP Pass replacement 中被调用（`sequence_parallelism.py:92,132,179`）。

**适用模型**：Qwen3-VL DeepStack。其他用 multi-tensor residual 的模型同模式。

---

## 3. MLA `need_gather_q_kv` 切换（`需复核` 行号）

**场景**：MLA attention 在 FC1 下，Q/K/V 已被 ReduceScatter 切到 `bs/TP`，不需要在 attention 内再 gather。

**位置**：`vllm_ascend/ops/mla.py`（行号 `需复核`）

**适用模型**：所有 MLA 架构（DeepSeek V2/V3 系列）。

---

## 4. MoE 入口/出口 all_gather（EP-group 通信路径选择）

**场景**：MoE forward 入口 `hidden_states` 是 `[bs/TP, H]`（FC1 ReduceScatter 后），router 需要完整 token 才能 token-wise 路由；出口需聚合回完整 `[bs, H]`。

**位置**：`vllm_ascend/ops/fused_moe/prepare_finalize.py:358,483`（`if enable_sp() or enable_sp_by_pass():`）

**关键点**：这是 **FC1/Pass 借给 MoE 的 EP-group 通信路径选择**，与 deepseek_v4 自身的 `use_sequence_parallel_moe`（第四类，chunk+all_gather）是两层不同机制，**不要混淆**。

**适用模型**：所有 MoE 模型（DeepSeek V3/V4、Qwen3-MoE、Bailing-MoE）。

---

## 5. Draft / MTP 模型最终层 all_gather

**场景**：Draft/MTP 模型默认 FC1 关闭（`ascend_forward_context.py:127-130`）。某些路径下仍可能开启，最终层输出 `[bs/TP, H]` 必须聚合回 `[bs, H]` 喂 lm_head，否则 NaN/shape 错。

**位置**：
- `vllm_ascend/spec_decode/llm_base_proposer.py:2029,2035,2056`（`if _EXTRA_CTX.flash_comm_v1_enabled:`）
  ⚠️ **旧文件名 `eagle_proposer.py` 已不存在**，现为 `llm_base_proposer.py`。
- `vllm_ascend/models/deepseek_v4_mtp.py`（MTP all_gather，`需复核` 行号）

**适用模型**：DeepSeek V4 MTP、Qwen3 Next MTP、Eagle spec decode。

---

## 6. Rotary Embedding Position all_gather（`需复核` 行号）

**场景**：FC1 切 token 后，positions tensor 也需对齐到 `bs/TP`，否则 RoPE 索引错位。

**位置**：`vllm_ascend/ops/rotary_embedding.py`（行号 `需复核`）

---

## 7. Worker 端 SP 标志 + pad 计算

**场景**：每步 forward 前，根据 `num_tokens` 动态决定是否启用 FC1（dense token 数不够则关闭），并计算 `pad_size` 让 bs 对齐 TP 整数倍。

**位置**：
- V1：`vllm_ascend/ascend_forward_context.py:122-142`（三分支标志 + `pad_size=(tp-num_tokens%tp)%tp` `:139-142`）
- V2：`vllm_ascend/platform.py:970-975`（gate `:940-941`）
- `_pad_for_sequence_parallelism`：`vllm_ascend/worker/model_runner_v1.py`（行号 `需复核`）

**适用场景**：所有 FC1 模型通用，无需手动适配。

---

## 8. Platform 启动期校验

**场景**：服务启动时校验 FC1 配置合法性。

**位置**：`vllm_ascend/platform.py:732-739`

**校验内容**：
```python
if enable_sp(vllm_config):
    assert tp_size > 1, "Flash Comm v1 is only supported when tp_size > 1."
    # MoE 时还要求 enable_expert_parallel
```

**适配启示**：新模型开 FC1 + MoE 时，必须同时开 `--enable-expert-parallel`。

---

## 9. W8A8 量化融合路径

**场景**：W8A8 量化下，`matmul_and_reduce` 走 `npu_mm_reduce_scatter_base` 的量化分支（分支C），融合 quant+matmul+reduce_scatter。

**位置**：`vllm_ascend/ops/linear_op.py:544-572`（分支B unquant `:530-542`，分支C w8a8 `:544-572`）

**适用模型**：Qwen3 W8A8 / W4A8 量化模型。

---

## 10. 310P GDN SP 路径

**场景**：310P 卡的 GDN attention 有独立 SP 实现路径，借 `enable_sp()` 做切片分叉（第二类借用）。

**位置**：`vllm_ascend/_310p/ops/fla/gdn_310.py:267,475,480`（`if not enable_sp():`）
  ⚠️ 旧文档的 `:81,252-262` 行号错。

**适配启示**：310P 模型不走主 FC1 CustomOp 路径，但需要 `enable_sp()` 触发其切片分支。

---

## 11. VL 模型走 SP Pass（Inductor）而非 CustomOp

**场景**：VL 模型在 graph 模式下，CustomOp FC1 在 layer-0 attn 让位（`linear_op.py:435`），由 Inductor Pass 做图模式 pattern 替换。

**位置**：
- `vllm_ascend/compilation/passes/sequence_parallelism.py:187` `SequenceParallelismPass`
- patterns：`MiddleAllReduceRMSNormPattern`(:56) / `LastAllReduceRMSNormPattern`(:102) / `Qwen3VLMiddleAllReduceRMSNormPattern`(:140)
- `vllm_ascend/compilation/passes/sequence_parallelism_moe.py`
- 注册门控：`graph_fusion_pass_manager.py:74` `if config.compilation_config.pass_config.enable_sp:`
- ⚠️ **Pass 桥**：`update_pass_config`（`model_runner_v1.py:5003-5011`）在编译期把 `pass_config.enable_sp = enable_sp()`，故开 FC1 时 Pass 自动拉起（`enable_sp_by_pass()` 也随之 True）。

**与 CustomOp FC1 的关系**：互补不互斥（非 VL 由 CustomOp 接管，all_reduce 已融合，Pass 匹配不到为 no-op；VL 由 Pass 接管）。

**适用模型**：Qwen3-VL 等多模态。

---

## 12. Linear 层 SP 分支（unique_prefix 注册）

**场景**：Ascend 线性层在 `enable_sp()` 时注册 `unique_prefix`，供 CustomOp 定位。

**位置**：`vllm_ascend/ops/linear.py:287`（`if enable_sp():`）
  ⚠️ 旧文档的 `:278` 行号错（那是 `out_dtype` 形参）。

**回退路径**：`linear.py:201-204` `if self.custom_op is not None: return self.custom_op.apply(input_)` 否则 `super().forward()` = 标准 TP linear。

---

## 13. 启动期 `use_sequence_parallel_moe` 处理（**纠正旧错误描述**）

**场景**：`platform.py:647-650` 有注释 `# TODO: this is a tricky way to disable use_sequence_parallel_moe in vllm.`

**真相**（源码确认）：注释声称 disable，但**实际代码只在 `not pass_config.enable_sp` 时改 `all2all_backend = "flashinfer_all2allv"`**，**并未真正 disable `use_sequence_parallel_moe`**。其值由上游 vllm `ParallelConfig.use_sequence_parallel_moe` 决定，vllm-ascend 内未 override。

**适配启示**：deepseek_v4 的 MoE SP（`deepseek_v4.py:367` `is_sequence_parallel = use_sequence_parallel_moe`）是**第四类独立机制**，不依赖 `enable_sp()`。可以用上游 `use_sequence_parallel_moe` 控制；FC1 由 `enable_flashcomm1` 控制。两者可独立。

---

## 14. Graph Fusion Pass Manager

**场景**：graph 模式下 FC1 相关融合 pass 的注册和调度。

**位置**：`vllm_ascend/compilation/graph_fusion_pass_manager.py:49-79`（`configure` 中按 `pass_config.enable_sp` 注册 SP Pass）

**适配启示**：新增 graph 模式 FC1 优化时，在此注册。

---

## 适配速查表

| 新模型遇到的问题 | 查阅 |
|-----------------|------|
| Layer0 崩溃（**仅 Qwen3-5**） | §1 `patch_qwen3_5.py:104-112` |
| Residual / DeepStack shape mismatch | §2 `patch_qwen3vl` + `maybe_chunk_residual` |
| MLA 模型 attention 报错 | §3 `mla.py` |
| MoE 模型 router 输入错 | §4 `prepare_finalize.py:358,483` |
| MTP / Draft 输出 NaN | §5 `llm_base_proposer.py:2029+`（非 eagle_proposer） |
| RoPE 位置索引错位 | §6 `rotary_embedding.py` |
| 启动报 "tp_size > 1" 错 | §8 `platform.py:732` |
| MoE 启动报 "enable_expert_parallel" 错 | §8 |
| W8A8 量化下 mmrs 不融合 | §9 `linear_op.py:544-572` |
| 310P 卡 GDN 不走 FC1 | §10 `gdn_310.py:267,475,480` |
| VL 模型 FC1 不生效 | §11 SP Pass |
| on/off 对比性能无差异（graph） | SP Pass 桥未断，见 SKILL.md §8.1 |
