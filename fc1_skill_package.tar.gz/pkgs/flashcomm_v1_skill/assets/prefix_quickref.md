# FC1 Prefix Quick Reference

> Line numbers verified 2026-07; locate by symbol name, not line.

## Row-parallel (FC1 ReduceScatter point — end of attention/mlp)

`linear_op.py:680-686` `sp_row_prefixes`, `in` 子串匹配 → `SequenceRowParallelOp`

| Prefix | Where | Notes |
|--------|-------|-------|
| `o_proj` | attention output | most LLMs |
| `out_proj` | attention output | Qwen3 Next |
| `down_proj` | MLP output / MoE routed expert / MoE pre-FFN | routed expert is MLP essentially |
| `attention.dense` | attention output | Bailing |
| `wo_b` | attention output | **DeepSeek V4**（`linear_op.py:685` 注释 `# attn output linear of v4`，易漏） |

**Excluded**: `shared_expert` (`linear_op.py:639,678` return None；上层 `get_parallel_op:696-700`)

## Column-parallel (FC1 AllGather point — start of attention/mlp)

`linear_op.py:641-647` `sp_column_prefix`, `in` 子串匹配 → `SequenceColumnParallelOp`

| Prefix | Where | Notes |
|--------|-------|-------|
| `gate_up_proj` | MLP gate/up | most LLMs |
| `in_proj` | gated deltanet | Qwen3 Next |
| `qkv_proj` | attention QKV | most LLMs |
| `conv1d` | gated deltanet | Qwen3 Next |
| `query_key_value` | attention QKV | Bailing |

## Priority (high → low, intercepts FC1)

**Column** (`_get_column_parallel_op:631-652`): DSA-CP(q_b/kv_b) → MLP TP → FC2 → **FC1**
**Row** (`_get_row_parallel_op:666-689`): DSA-CP(o_proj) → MLP TP → OProj TP → MatmulAllReduce → FC2 → **FC1**

> DSA-CP 列并行条件是 `q_b_proj/kv_b_proj`，行并行条件才是 `o_proj`/`wo_b` — 别笼统说"DSA-CP 命中 o_proj/qkv"。

## Activation conditions (V1, `ascend_forward_context.py:122-132` — **三分支**)

```
if is_context_moe_model:                          # :123-126  (MoE / drafter MoE)
    flash_comm_v1_enabled = enable_sp() and num_tokens is not None    # 无 1000 阈值
    mmrs_fusion = False
elif is_draft_model:                              # :127-130  (dense drafter)
    flash_comm_v1_enabled = False                 # 强制关
else:                                             # :131-132  (dense 主模型)
    flash_comm_v1_enabled = enable_sp() and num_tokens is not None and num_tokens > 1000
```
V2 路径同结构在 `platform.py:970-975`（gate `:940-941`）；V2 下 `mmrs_fusion` 恒 True（`:970`，MoE 覆盖为 False）。

```
enable_sp()  =  enable_flashcomm1   (additional_config / AscendConfig / env VLLM_ASCEND_ENABLE_FLASHCOMM1)
mmrs_fusion  =  (tp_world_size <= 8)            # ascend_forward_context.py:113 (V1)；npu_mm_reduce_scatter_base 不支持 tp>=16
pad_size     =  (tp - num_tokens % tp) % tp     # ascend_forward_context.py:139-142
```

## SP Pass bridge（**易漏，影响失效**）

开 FC1 → `update_pass_config`（`model_runner_v1.py:5003-5011`，调用点 `:4788`）把 `pass_config.enable_sp = enable_sp()` → SP Inductor Pass 注册（`graph_fusion_pass_manager.py:74`）。
- 非 VL graph 模式：CustomOp 已把 all_reduce 融进 `matmul_and_reduce`，Pass pattern 匹配不到 → no-op，不冲突。
- VL graph 模式：CustomOp 在 layer-0 attn 让位（`linear_op.py:435`），Pass 接管。
- **失效 FC1 时**：graph 模式必须断此桥，否则 Pass 接管 SP（见 `disable_fc1.diff` hunk 4）。

## Quick lookup

```bash
# FC1 CustomOp entry (column / row)
grep -n "if enable_sp():" vllm_ascend/ops/linear_op.py        # → 638 (col), 677 (row)

# All 4 branches inside matmul_and_reduce
grep -n "if not flash_comm_v1_enabled\|if mmrs_fusion\|tensor_model_parallel_reduce_scatter" vllm_ascend/ops/linear_op.py

# Custom op impls (impl def line ≠ register line)
grep -n "def _.*_impl" vllm_ascend/ops/register_custom_ops.py  # → 40 / 73 / 159 (impl)
grep -n "direct_register_custom_op" vllm_ascend/ops/register_custom_ops.py  # → 228 / 236 / 268 (register)

# Runtime flag (V1 / V2)
grep -n "flash_comm_v1_enabled = enable_sp" vllm_ascend/ascend_forward_context.py  # → 125 / 132
grep -n "flash_comm_v1_enabled = enable_sp" vllm_ascend/platform.py                # → 972 / 975

# Pass bridge
grep -n "pass_config.enable_sp = enable_sp" vllm_ascend/worker/model_runner_v1.py  # → 5008
```
