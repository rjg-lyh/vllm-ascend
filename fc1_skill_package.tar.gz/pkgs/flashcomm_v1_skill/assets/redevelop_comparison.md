# 博弈论练习：失效 FC1 → 用 skill 重做 → 与原仓对比

> 模型基线：**Qwen3-32B 稠密**（TP>1, graph 或 eager）。
> 目的（任务一 1.4）：先学会精确失效仓库已适配的 FC1，再用 skill playbook 从零重做，与原仓代码逐点对比，判 skill 孰对孰错孰优孰劣。

## 阶段一：精确失效 FC1（"该删/改哪些代码"）

### 1.1 失效点定位（源码确认）

| # | 文件:行 | 原代码 | 改法 | 作用 |
|---|--------|--------|------|------|
| 1 | `linear_op.py:638` | `if enable_sp():`（列并行入口） | `if False:` | gate_up/qkv 回退标准 ColumnParallelLinear |
| 2 | `linear_op.py:677` | `if enable_sp():`（行并行入口） | `if False:` | o_proj/down_proj 回退标准 RowParallelLinear+AllReduce |
| 3 | `ascend_forward_context.py:132` | `flash_comm_v1_enabled = enable_sp(...) and ... > 1000` | `= False` | V1 dense 标志（堵 Eagle/patch 残留分支） |
| 4 | `platform.py:975` | 同上 | `= False` | V2 dense 标志 |
| 5（graph） | `model_runner_v1.py:5008` | `pass_config.enable_sp = enable_sp(...)` | `= False` | 断 SP Pass 桥，否则 Pass 接管 SP |

- **eager 模式**：改 1-4 即可（Pass 不参与）。
- **graph 模式**：1-5 全改，否则 on/off 对比被 Pass 污染。
- **回退路径已确认**：`get_parallel_op`（`linear_op.py:694-723`）返回 None → `custom_op=None` → `AscendQKVParallelLinear.forward`（`linear.py:201-204`）走 `super().forward()`。
- **副作用隔离已确认**：DSA-CP（`linear_op.py:631,666` 优先级高于 FC1）、shared_expert_dp（`utils.py:877`）、310p GDN（`gdn_310.py:267`）、PCP（`ascend_config.py:123`）均不依赖被改的 4+1 处，全部存活。

> 完整 diff 见 `assets/disable_fc1.diff`。

### 1.2 旧 skill 的失效方案错在哪（对比证据）

| 旧 SKILL.md §8.1 断言 | 实际 | 后果 |
|----------------------|------|------|
| "A1 两处即可堵住入口"（只改 linear_op 两处） | 不够，还需 V1/V2 标志两处 | Eagle proposer / Qwen3-5 Layer0 patch 仍进 FC1 分支可能崩 |
| 行号 `linear_op.py:637-651 / 676-689` | 实际 `638-652 / 677-689` | 照搬改错行 |
| `ascend_forward_context.py:118,125` | 实际 dense 在 `:132`（`:125` 是 MoE 分支） | 堵错分支，dense FC1 仍开 |
| `platform.py:718,721` | 实际 V2 在 `:970-975`（`:718` 是 use_sparse） | V2 路径完全没堵 |
| "SP Pass 不受影响"（暗示 4 行足够） | graph 模式下 Pass 会接管 SP | on/off 对比失效，SP 没真关 |
| 未提 `model_runner_v1.py:5008` Pass 桥 | 必须断桥 | graph 模式失效不完整 |

**结论**：旧 skill 的失效方案在 eager 模式下也漏了 V1/V2 标志两处，在 graph 模式下更完全失效。重构后 skill（§8.1 + `disable_fc1.diff`）给出 eager 4 行 / graph 5 行的完整方案。

---

## 阶段二：用 skill playbook 从零重做 FC1（Qwen3-32B dense）

按重构后 skill 的 §3 决策树走：

```
1. Qwen3 dense 用 Ascend 线性层？
   → 是。靠 REGISTERED_ASCEND_OPS 类名映射注入（utils.py:684-712），上游 qwen3.py 的
     QKVParallelLinear/RowParallelLinear/MergedColumnParallelLinear 自动映射成 Ascend* 版本。
2. prefix 在 §2.1 列表？
   → 是。qkv_proj / o_proj / gate_up_proj / down_proj 全部命中（linear_op.py:641-647,680-686）。
3. 高优先级 op 拦截？（§2.2）
   → 否。Qwen3 dense 无 index_topk（不走 DSA-CP）、不开 MLP TP、不开 FC2。
4. 是 VL 模型？→ 否。
5. 是 Draft/MTP？→ 否。
6. 需特殊 patch？（§4.3）
   → 否。Qwen3 dense 无预分配 buffer（Qwen3DecoderLayer.forward 直接 return hidden_states），
     Layer0 patch 是 Qwen3-5 专属，不套用。
→ ✓ FC1 就绪，零代码改动，设 enable_flashcomm1=1 即可。
```

**重做产出**：0 行代码改动 + 启动参数 `VLLM_ASCEND_ENABLE_FLASHCOMM1=1`（或 `additional_config.enable_flashcomm1=true`）+ `tp_size>1`。

---

## 阶段三：与原仓代码逐点对比

| 维度 | skill 重做 | 原仓代码 | 一致？ |
|------|-----------|---------|--------|
| 模型文件 | 复用上游 `vllm/vllm/model_executor/models/qwen3.py` | 同（`vllm_ascend/models/` 无 qwen3 文件） | ✅ |
| 线性层注入 | `REGISTERED_ASCEND_OPS` 类名映射 | 同（`utils.py:684-712`） | ✅ |
| 前缀命中 | qkv_proj/o_proj/gate_up_proj/down_proj | 同（`linear_op.py:641-686`） | ✅ |
| 需要的 patch | 无 | 无（dense Qwen3 无专属 patch） | ✅ |
| 开启方式 | `enable_flashcomm1=1` | 同（`envs.py:75` / `ascend_config.py:83-88`） | ✅ |
| Layer0 buffer patch | **不套用**（skill §4.3 标注 Qwen3-5 专属） | 原仓 dense Qwen3 无此 patch | ✅ |

**重做结论**：对 Qwen3-32B dense，skill 重做与原仓**完全一致**——零代码、靠类名映射 + 标准前缀 + env 开关。skill 的决策树正确识别了"无需适配"。

---

## 阶段四：孰对孰错孰优孰劣

### 4.1 旧 skill vs 重构 skill vs 原仓（三方对比）

| 能力 | 旧 skill | 重构 skill | 原仓（地面真相） |
|------|---------|-----------|----------------|
| FC1 原理 | ✓ 正确 | ✓ 正确 | — |
| 行号准确性 | ✗ 全部偏移 50-70 行 | ✓ 核实 | — |
| 行并行前缀 | ✗ 漏 `wo_b` | ✓ 5 项 | 5 项 |
| FC1 激活条件 | ✗ 只讲单分支 | ✓ 三分支（MoE/draft/dense） | 三分支 |
| DSA-CP 判定 | ✗ `is_ds_v32` | ✓ `hasattr(index_topk)` | `hasattr(index_topk)` |
| 旧 env 名兼容 | ✗ 凭空声称 | ✓ 澄清不存在 | 不存在 |
| ds32 TODO | ✗ 凭空引用 | ✓ 澄清不存在 | 不存在 |
| Layer0 patch 归属 | ✗ 当通用场景 | ✓ 标 Qwen3-5 专属 | Qwen3-5 专属 |
| matmul 分支 | ✗ 三分支+else含all_gather | ✓ 四分支+else仅reduce_scatter | 四分支 |
| SP Pass 桥 | ✗ 未提 | ✓ §1.5/§8 显式 | `update_pass_config` 存在 |
| 失效方案完整性 | ✗ eager 漏 V1/V2，graph 全失效 | ✓ eager 4 / graph 5 | — |
| FC1本体 vs 借用旁路 | ✗ 混讲 | ✓ 四类分离 | — |
| Qwen3 dense 适配判定 | ✓ 零改动（正确） | ✓ 零改动（正确） | 零改动 |

### 4.2 判定

- **旧 skill 对 Qwen3 dense 的"能否开 FC1"判断是对的**（零改动），但对"怎么失效""哪些是 FC1 本体""行号在哪"几乎全错——**对简单场景够用，对需要动手适配/失效的场景会误导**。
- **重构 skill 对所有维度与原仓对齐**，且把"FC1 本体 vs 借用旁路"四类分离讲清——这是适配开发时不破坏其他特性的关键。
- **重做与原仓一致**证明：skill 的决策树 + 前缀表 + 类名映射认知是正确的，能自动导出与原仓相同的适配结论（零代码）。
- **失效方案的演进**（旧 4 行 → 新 eager 4 + graph 5）是"博弈论练习"最直接的收益：只有先学会精确失效，才能证明你真懂 FC1 的代码边界——而旧 skill 的失效方案恰恰暴露了它没真懂（漏 V1/V2 标志、漏 Pass 桥）。

### 4.3 skill 还能更好的地方（诚实记录）

1. **未在真实 NPU 实跑验证**：本次重做/失效均源码级分析，未跑 on/off 性能对比与精度评测。skill 的能力③（测试/评测）目前是"可运行脚本+流程"，性能/精度数字需在昇腾环境实跑回填。
2. **部分行号标 `需复核`**：`mla.py`/`rotary_embedding.py`/`patch_qwen3vl.py`/`_pad_for_sequence_parallelism` 的行号未逐行确认，catalog 中已标注。
3. **`enable_sp_by_pass` 与 `update_pass_config` 的覆盖语义**：`update_pass_config` 在编译期把 `pass_config.enable_sp` 覆写为 `enable_sp()`，意味着用户单独设 `pass_config.enable_sp=True`（不带 `enable_flashcomm1`）可能被覆写为 False——这一交互的完整语义未在本技能穷尽验证，建议实测确认。

---

## 附录：关键发现速查

- **坑1**：旧 skill 行号全漂移 → 重构时改"以符号名定位，行号仅供参考"。
- **坑2**：旧 skill 把 Layer0 patch 当通用 → 重构标 Qwen3-5 专属，避免误套。
- **坑3**：旧 skill 失效方案漏 V1/V2 标志 + 漏 Pass 桥 → 重构出 eager/graph 双方案。
- **坑4**：旧 skill 混讲 FC1/DSA-CP/SP Pass → 重构出四类分离表。
- **博弈论收益**：失效练习反推出"SP Pass 桥"这个旧 skill 完全没意识到的耦合点。
