#!/usr/bin/env python3
"""FC1 runtime diagnostic — drop into model forward to verify FC1 status.

Usage:
    from fc1_check import fc1_check
    fc1_check()            # call inside forward()
    fc1_check_verbose()    # also print enable_sp / enable_dsa_cp / enable_sp_by_pass

Verified against vllm-ascend (2026-07): _EXTRA_CTX (ascend_forward_context.py:381)
exposes flash_comm_v1_enabled / mmrs_fusion / pad_size (extra_attrs :325-349).
"""
import torch.distributed as dist

try:
    from vllm_ascend.ascend_forward_context import _EXTRA_CTX
except Exception as e:  # import-time safety
    _EXTRA_CTX = None
    _IMPORT_ERR = e


def _ctx_attr(name, default="N/A"):
    if _EXTRA_CTX is None:
        return f"<no_ctx:{_IMPORT_ERR}>"
    return getattr(_EXTRA_CTX, name, default)


def fc1_check(tag: str = ""):
    """Print FC1 runtime status. Safe to call in any forward pass."""
    rank = dist.get_rank() if dist.is_initialized() else 0
    tp = dist.get_world_size() if dist.is_initialized() else 1
    print(
        f"[FC1 check {tag}] rank={rank} tp={tp} "
        f"fc1={_ctx_attr('flash_comm_v1_enabled')} "
        f"mmrs={_ctx_attr('mmrs_fusion')} "
        f"pad={_ctx_attr('pad_size')}"
    )


def fc1_check_verbose(tag: str = ""):
    """Verbose — also resolves the switch chain (enable_sp / enable_dsa_cp / enable_sp_by_pass).

    Use this to tell apart:
      - FC1 本体 (enable_sp) vs DSA-CP (enable_dsa_cp) vs SP Pass (enable_sp_by_pass)
      - why fc1=False: env off / dense token<1000 / tp=1 / draft / MoE(无阈值)
    """
    fc1_check(tag)
    if rank := (dist.get_rank() if dist.is_initialized() else 0):
        return
    if _EXTRA_CTX is None:
        return
    try:
        from vllm_ascend.utils import (
            enable_sp,
            enable_dsa_cp,
            enable_sp_by_pass,
            shared_expert_dp_enabled,
        )
        print(
            f"  enable_sp={enable_sp()} "
            f"enable_sp_by_pass={enable_sp_by_pass()} "
            f"dsa_cp={enable_dsa_cp()} "
            f"shared_expert_dp={shared_expert_dp_enabled()}"
        )
    except Exception as e:
        print(f"  <switch chain unavailable: {e}>")
