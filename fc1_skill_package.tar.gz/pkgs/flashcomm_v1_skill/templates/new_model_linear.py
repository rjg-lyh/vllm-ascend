"""Template: new model Linear layer setup for FC1 auto-enable.

Copy this pattern into any new model architecture. As long as prefixes
match the FC1 prefix list (see assets/prefix_quickref.md), FC1 activates
with zero code changes.

Key rules:
1. Use Ascend*Linear classes (not vanilla vllm ParallelLinear)
2. Pass prefix to EVERY linear layer
3. Use standard names: qkv_proj/o_proj/gate_up_proj/down_proj
"""
from vllm_ascend.ops.linear import (
    AscendMergedColumnParallelLinear,
    AscendQKVParallelLinear,
    AscendRowParallelLinear,
)


class MyModelAttention(nn.Module):
    def __init__(self, prefix: str, hidden_size: int, q_size: int, kv_size: int):
        super().__init__()
        # Column-parallel — FC1 all-gather point (next matmul)
        self.qkv_proj = AscendQKVParallelLinear(
            hidden_size=hidden_size,
            q_size=q_size,
            kv_size=kv_size,
            bias=False,
            prefix=f"{prefix}.qkv_proj",  # ← hits "qkv_proj"
        )
        # Row-parallel — FC1 reduce-scatter point
        self.o_proj = AscendRowParallelLinear(
            input_size=q_size,
            output_size=hidden_size,
            bias=False,
            prefix=f"{prefix}.o_proj",  # ← hits "o_proj"
        )


class MyModelMLP(nn.Module):
    def __init__(self, prefix: str, hidden_size: int, intermediate_size: int):
        super().__init__()
        # Column-parallel — FC1 all-gather point
        self.gate_up_proj = AscendMergedColumnParallelLinear(
            input_size=hidden_size,
            output_size=intermediate_size * 2,  # gate + up
            bias=False,
            prefix=f"{prefix}.gate_up_proj",  # ← hits "gate_up_proj"
        )
        # Row-parallel — FC1 reduce-scatter point
        self.down_proj = AscendRowParallelLinear(
            input_size=intermediate_size,
            output_size=hidden_size,
            bias=False,
            prefix=f"{prefix}.down_proj",  # ← hits "down_proj"
        )


class MyModelMoEExpert(nn.Module):
    """MoE routed expert — its down_proj auto-enters FC1."""
    def __init__(self, prefix: str, hidden_size: int, intermediate_size: int):
        super().__init__()
        self.gate_up_proj = AscendMergedColumnParallelLinear(
            hidden_size, intermediate_size * 2, bias=False,
            prefix=f"{prefix}.gate_up_proj",
        )
        self.down_proj = AscendRowParallelLinear(
            intermediate_size, hidden_size, bias=False,
            prefix=f"{prefix}.down_proj",
        )


# NOTE: shared_expert is auto-excluded by FC1 (linear_op.py:638,677).
# No special handling needed.
