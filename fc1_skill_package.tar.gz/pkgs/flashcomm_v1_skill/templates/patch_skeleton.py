"""Template: model-specific FC1 patch skeleton.

Use when a model needs special handling (Layer0 buffer, residual chunk,
MTP all_gather, etc.). Register in vllm_ascend/patch/worker/patch_*.py
and apply via adapt_patch(is_global_patch=False).

Common patch patterns:
- Layer0 attention output buffer: shrink to ceil(seq/TP) × dim
- Residual / DeepStack: chunk by tp_size before add
- MTP final layer: tensor_model_parallel_all_gather before output
- MLA: toggle need_gather_q_kv
"""
import torch
from vllm_ascend.ascend_forward_context import _EXTRA_CTX


def patch_layer_zero_attention(my_model):
    """Pattern: shrink Layer0 attention output buffer.

    Layer0 receives full-seq input from embed_tokens; subsequent layers
    receive bs/TP tokens (post ReduceScatter). Layer0's attention output
    buffer must shrink accordingly or shape mismatch crashes.

    Reference: vllm_ascend/patch/worker/patch_qwen3_5.py
    """
    for layer_idx, layer in enumerate(my_model.model.layers):
        if layer_idx != 0:
            continue
        original_forward = layer.self_attn.forward

        def patched_forward(*args, **kwargs):
            if not _EXTRA_CTX.flash_comm_v1_enabled:
                return original_forward(*args, **kwargs)
            # ... shrink output buffer to ceil(seq/TP) × dim ...
            return original_forward(*args, **kwargs)

        layer.self_attn.forward = patched_forward


def patch_residual_chunk(my_model):
    """Pattern: chunk residual by tp_size before add.

    When FC1 is on, attention/mlp output is [bs/TP, H] but residual may
    still be [bs, H]. Chunk residual before element-wise add.

    Reference: vllm_ascend/patch/worker/patch_qwen3vl.py
    """
    tp = torch.distributed.get_world_size()
    for layer in my_model.model.layers:
        original_forward = layer.forward

        def patched_forward(hidden_states, *args, **kwargs):
            if not _EXTRA_CTX.flash_comm_v1_enabled:
                return original_forward(hidden_states, *args, **kwargs)
            # hidden_states shape: [bs/TP, H] after ReduceScatter
            # residual shape: [bs, H] — must chunk to [bs/TP, H]
            chunk_size = hidden_states.shape[0]
            residual = kwargs.get("residual", None)
            if residual is not None and residual.shape[0] != chunk_size:
                residual = residual.chunk(tp, dim=0)[torch.distributed.get_rank()]
                kwargs["residual"] = residual
            return original_forward(hidden_states, *args, **kwargs)

        layer.forward = patched_forward


def patch_mtp_final_all_gather(my_model):
    """Pattern: all_gather MTP draft final layer output.

    MTP/draft model produces next-token logits; if FC1 is on, final
    hidden is [bs/TP, H] → must all_gather to [bs, H] before lm_head,
    else NaN/wrong shape.

    Reference: vllm_ascend/models/deepseek_v4.py
    """
    from vllm_ascend.distributed import get_tp_group
    original_forward = my_model.forward

    def patched_forward(*args, **kwargs):
        out = original_forward(*args, **kwargs)
        if _EXTRA_CTX.flash_comm_v1_enabled:
            out = get_tp_group().all_gather(out, 0)
        return out

    my_model.forward = patched_forward
