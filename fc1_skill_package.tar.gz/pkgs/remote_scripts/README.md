# Remote Verification Scripts

辅助脚本，用于在昇腾 NPU 服务器上远程执行验证命令。

## 环境准备

1. 安装 sshpass：`brew install hudochenkov/sshpass/sshpass`（macOS）或 `apt-get install sshpass`（Linux）

2. 在同目录下创建 `login_info.md`（**不要提交到仓库**）：

```
- ip: <your_server_ip>
- username: root
- password: <your_password>
- docker container name: <container_name>
- path of workspace: <work_dir>
```

3. 在 `remote_exec.sh` 中替换 `<WORK_DIR>` 为实际工作目录。

## 使用

```bash
# 单命令执行
./remote_exec.sh "npu-smi info"

# 复杂脚本用 base64 传输（避免嵌套引号问题）
cat << 'EOF' | base64
#!/bin/bash
echo "hello from remote"
EOF
# 复制输出的 base64, 然后:
./remote_exec.sh "echo '<b64>' | base64 -d | bash"
```

## 常见坑

- docker exec 用 `-i` 不要用 `-it`（非交互场景 TTY 会报错）
- macOS 的 BSD grep 不支持 `-P`，用 `sed -n 's/.../p'` 替代
- 杀掉 NPU 孤儿进程用 `pkill -9 VLLM`（大写），`pkill -9 python` 清不掉驱动残留
