#!/bin/bash
# Optional output wrapper: pipe remote_exec.sh output through this for visual distinction
# Usage: ./remote_exec.sh "cmd" | ./remote_display.sh

HEADER="==================== REMOTE SERVER ===================="

echo "$HEADER"
while IFS= read -r line; do
    echo "| $line"
done
echo "=========================================================="
