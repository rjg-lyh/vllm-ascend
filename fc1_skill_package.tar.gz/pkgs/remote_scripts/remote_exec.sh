#!/bin/bash
# Remote execution wrapper for NPU servers
# Usage: ./remote_exec.sh "<command>"
#
# Prerequisites:
#   1. Install sshpass: brew install hudochenkov/sshpass/sshpass (macOS)
#      or apt-get install sshpass (Linux)
#   2. Create login_info.md in the same directory:
#      - ip: <server_ip>
#      - username: root
#      - password: <password>
#      - docker container name: <container_name>
#      - path of workspace: <work_dir>

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOGIN_FILE="$SCRIPT_DIR/login_info.md"
IP=$(sed -n 's/.*ip: \([^ ]*\).*/\1/p' "$LOGIN_FILE")
PASS=$(sed -n 's/.*password: \([^ ]*\).*/\1/p' "$LOGIN_FILE")
CONTAINER=$(sed -n 's/.*container name: \([^ ]*\).*/\1/p' "$LOGIN_FILE")

if [ -z "$1" ]; then
    echo "Usage: $0 \"<command>\""
    exit 1
fi

sshpass -p "$PASS" ssh -o StrictHostKeyChecking=no root@$IP \
    "docker exec -i -u root $CONTAINER bash -c 'cd <WORK_DIR> && $1'"

# Tip: for commands with deep nested quotes, use base64 transfer:
#   cat << 'EOF' | base64  →  echo '<b64>' | base64 -d > remote_script.sh
